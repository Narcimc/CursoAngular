import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { MainPageComponent } from './pages/main-pages.component';



@NgModule({
  declarations: [
    MainPageComponent,
  ],
  exports:[
    MainPageComponent,
  ],
  imports: [
    RouterModule.forRoot(routes),
    CommonModule
  ]
})
export class DbzModule { }

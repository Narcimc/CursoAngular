import { Component} from '@angular/core';

@Component({
  selector: 'app-dbz',
  templateUrl: './main-pages.component.html'
})

export class MainPageComponent  {

}
